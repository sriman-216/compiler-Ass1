#include <iostream>
#include <vector>
#include <map>
#include <limits.h>
using namespace std;

int trap(vector<int> heights) 
{
int n = heights.size(); int left_max = 0; int right_max = heights[n - 1]; int l = 0; int r = n - 1; int ans = 0; {
while(l <= r) {
if(left_max < right_max) {
int k = left_max - heights[l]; if(k > 0) {
ans = ans + k;
} if(left_max < heights[l]) {
left_max = heights[l];
} l = l + 1;
} else {
int k = right_max - heights[r]; if(k > 0) {
ans = ans + k;
} if(right_max < heights[r]) {
right_max = heights[r];
} r = r - 1;
}
}

} return ans;
}

int main () {
vector<int> heights; heights.push_back(4); heights.push_back(2); heights.push_back(0); heights.push_back(3); heights.push_back(2); heights.push_back(5); int result = trap(heights); cout << result << endl;
}
