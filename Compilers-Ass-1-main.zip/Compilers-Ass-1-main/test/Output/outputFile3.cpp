#include <iostream>
#include <vector>
#include <map>
#include <limits.h>
using namespace std;

void second_smallest(vector<int> nums, int n) 
{
if(n < 2) {
cout << -1 << endl;
} int small_temp = INT_MAX; int second_small = INT_MAX; int i; {
i = 0;
while(i < n) {
if(nums[i] < small_temp) {
second_small = small_temp; small_temp = nums[i];
} else if(nums[i] < second_small && nums[i] != small_temp) {
second_small = nums[i];
}
i = i + 1;
if(!(i < n)) {
cout << second_small << endl;
}
}

} 
}

void second_largest(vector<int> nums, int n) 
{
if(n < 2) {
cout << -1 << endl;
} int large = INT_MIN; int second_large = INT_MIN; int i; {
i = 0;
while(i < n) {
if(nums[i] > large) {
second_large = large; large = nums[i];
} else if(nums[i] > second_large && nums[i] != large) {
second_large = nums[i];
}
i = i + 1;
if(!(i < n)) {
cout << second_large << endl;
}
}

} 
}

int main () {
vector<int> nums; nums.push_back(1); nums.push_back(2); nums.push_back(4); nums.push_back(7); nums.push_back(7); nums.push_back(5); int n = nums.size(); second_smallest(nums, n); second_largest(nums, n);
}
