#include <iostream>
#include <vector>
#include <map>
#include <limits.h>
using namespace std;

int uniquePaths(int m, int n) 
{
int N = n + m - 2; int r = m - 1; float res = 1; {
int i = 1;
while(i <= r) {
res = res * (N - r + i) / i;
i = i + 1;
}

} return res;
}

int main () {
int m = 7; int n = 3; int totalCount = uniquePaths(m, n); cout << totalCount << endl;
}
