#include <iostream>
#include <vector>
#include <map>
#include <limits.h>
using namespace std;

vector<vector<int>> three_sum(vector<int> nums) 
{
int n = nums.size(); vector<vector<int>> final; int j = 0; int k; {
int i = 0;
while(i <= (n - 3)) {
if(((i > 0 && nums[i] != nums[i - 1]) || i == 0)) {
j = i + 1; k = n - 1; int sum = -1 * nums[i]; {
while(j < k) {
if((nums[j] + nums[k]) > sum) {
k = k - 1;
} else if((nums[j] + nums[k]) < sum) {
j = j + 1;
} else {
vector<int> temp; temp.push_back(nums[i]); temp.push_back(nums[j]); temp.push_back(nums[k]); final.push_back(temp); if(j + 1 < n) {
int flag = 0; {
while(j + 1 < n && flag == 0) {
if(nums[j] == nums[j + 1]) {
j = j + 1;
} else {
flag = 1;
}
}

}
} j = j + 1; k = k - 1;
}
}

}
}
i = i + 1;
}

} return final;
}

int main () {
vector<int> nums; nums.push_back(-4); nums.push_back(-1); nums.push_back(-1); nums.push_back(0); nums.push_back(1); nums.push_back(2); vector<vector<int>> final = three_sum(nums); int i = 1; {
int j = 0;
while(j < final[i].size()) {
cout << final[i][j] << endl;
j = j + 1;
}

}
}
